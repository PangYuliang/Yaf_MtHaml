<?php

function __MtHamlTemplate_c3480a568e90a13f0f9b9140dc10d8c3f212b1af82801458f8a598e7ee224e47($__variables)
{
    extract($__variables);
?><!DOCTYPE html>
<head>
  <title>index.haml</title>
</head>
<body>
  <header>this public head template!</header>
</body>
<?php
}