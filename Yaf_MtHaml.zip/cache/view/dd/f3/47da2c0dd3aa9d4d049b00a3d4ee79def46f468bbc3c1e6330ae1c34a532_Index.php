<?php

function __MtHamlTemplate_ddf347da2c0dd3aa9d4d049b00a3d4ee79def46f468bbc3c1e6330ae1c34a532($__variables)
{
    extract($__variables);
?><?php
}