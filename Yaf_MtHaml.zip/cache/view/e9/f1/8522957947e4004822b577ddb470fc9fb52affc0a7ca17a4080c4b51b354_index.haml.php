<?php

function __MtHamlTemplate_e9f18522957947e4004822b577ddb470fc9fb52affc0a7ca17a4080c4b51b354($__variables)
{
    extract($__variables);
?><?php Template::set(null,'header.haml'); ?>
<h1>This is Index Page! Love Haml</h1>
<h2><?php echo htmlspecialchars($data,ENT_QUOTES,'UTF-8'); ?></h2>
<a href="http:://www.haml.org">HAML</a>
<address>Aninet_Pang</address>
<?php
}