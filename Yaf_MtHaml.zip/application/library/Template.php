
<?php
class Template extends MtHamlAdapter{

    static public function set($path = null, $name) {
        Yaf_Registry::get('haml')->template($path,$name);
    }

    //like this
    // public static function push ( $path=null, $name ){
    //     $file = $path.$name;
    //     Yaf_Registry::get('haml')->template('siderbar.haml');
    // }

    public static function make($condition, $value, $str){
        if($condition === $value){
            return $str;
        }
    }
}
