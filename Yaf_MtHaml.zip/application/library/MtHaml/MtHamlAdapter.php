<?php
Yaf_Loader::Import("MtHaml/Environment.php");
class MtHamlAdapter implements Yaf_View_Interface {
    protected $_mthaml = null;
    protected $_executor = null;
    protected $_template_dir = null;
    protected $_params = [];
    protected $_temp = null;
    protected $_options = [];
    protected $_module = null;

    
    public function __construct($tmplPath = null, $extraParams = []) {
        $mthaml = new MtHaml\Environment('php');
        $this->_executor = new MtHaml\Support\Php\Executor($mthaml,['cache' => $extraParams['cache']]);
        if (null !== $tmplPath) {
            $this->setScriptPath($tmplPath);
        }
        $this->_options = $extraParams;
    }

    public function getScriptPath(){
        return $this->_template_dir;
    }
    
    public function setScriptPath($path)
    {
        if (is_readable($path)) {
            $this->_template_dir = $path;
            return;
        }
    }
    
    public function __set($key, $val){
        $this->_params[$key] =  $val;
    }
 
    public function __isset($key){
        return (null !== array_key_exists($key,$this->_params));
    }
 
    public function __unset($key)
    {
        unset($this->_params[$key]);
    }

    public function assign($spec, $value = null) {
        if (is_array($spec)) {
            $this->_params[$spec];
            return;
        }
 
        $this->_params[$spec] = $value;
    }

    public function clearVars() {}

    public function render($tpl, $tpl_vars = NULL) {
        if($tpl_vars === null){
            $tpl_vars = [];
        }
        
        $request = Yaf_Dispatcher::getInstance()->getRequest();
        $module = $request->module;
        $file = $this->_options['path'].'/'.$module.'/'.$tpl;
        $variable = $tpl_vars + $this->_params;
        return $this->_executor->render($file , $variable);
        
    }


    public function display( $tpl, $tpl_vars = null) {

        $this->render($tpl, $tpl_vars);
        // var_dump($tpl);
        // if($tpl_vars === null){
        //     $tpl_vars = [];
        // }
        // if($tpl != null){
        //     var_dump($tpl_vars);
        //     $this->_executor->display($this->path().$tpl.'.haml' , $tpl_vars);
        // }else{
        //     // var_dump($value);
        //     var_dump($tpl_vars);

        //     $this->_executor->display($this->full_path() . '.haml' , $tpl_vars);
        // }
    }

    //In the haml file
    //you can 
    public function template($tpl){
        $request = Yaf_Dispatcher::getInstance()->getRequest();
        $module = $request->module;
        $file = $this->_options['path'].'/'.$module.'/'.$tpl;
        return $this->_executor->display($file,[]);
    }
    
    public function show(){
        $this->display(null,[]);
    }
    
    //you can delete this function
    public function path(){
        $dispatcher = Yaf_Dispatcher::getInstance();
        $request = $dispatcher->getRequest();
        $path = $this->_options['path'].'/'. $request->module .'/'. $request->controller;
        return $path;
        
    }

    //you can delete this function
    public function full_path(){
        $dispatcher = Yaf_Dispatcher::getInstance();
        $request = $dispatcher->getRequest();
        $path = $this->_options['path'].'/'.$request->module .'/'. $request->controller .'/'. $request->action;
        return $path;
        
    }
}
