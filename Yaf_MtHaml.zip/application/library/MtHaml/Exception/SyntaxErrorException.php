<?php

namespace MtHaml\Exception;

use MtHaml\Exception;

class SyntaxErrorException extends Exception
{
}
