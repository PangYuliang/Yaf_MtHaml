<?php

namespace MtHaml;

use MtHaml\Exception;

class TreeBuilderException extends Exception
{
}
