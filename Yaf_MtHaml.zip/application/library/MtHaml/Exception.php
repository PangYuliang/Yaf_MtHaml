<?php

namespace MtHaml;

use Exception as ExceptionBase;

class Exception extends ExceptionBase
{
}
