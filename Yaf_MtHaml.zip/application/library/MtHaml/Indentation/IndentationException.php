<?php

namespace MtHaml\Indentation;

use MtHaml\Exception;

class IndentationException extends Exception
{
}
