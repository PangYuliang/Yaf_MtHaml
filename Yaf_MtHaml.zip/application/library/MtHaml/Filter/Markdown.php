<?php

namespace MtHaml\Filter;

abstract class Markdown extends OptimizableFilter
{
}
