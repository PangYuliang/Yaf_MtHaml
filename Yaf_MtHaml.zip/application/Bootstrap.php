<?php

class Bootstrap extends Yaf_Bootstrap_Abstract
{
    public function _init_(Yaf_Dispatcher $dispatcher) {
        $config = $dispatcher->getApplication()->getConfig();
        $loader = Yaf_Loader::getInstance();
        
        //setView
        $loader->registerLocalNamespace('MtHaml');
        $mthaml = $config->mthaml->toArray();
        $haml = new MtHamlAdapter(null,$mthaml);
        $dispatcher->setView($haml);

        //add haml instance
        Yaf_Registry::set('haml', $haml);
    }
}
