<?php

class IndexController extends Yaf_Controller_Abstract
{
    public function indexAction(){
     
        $test = 'test';
        $this->_view->assign('data',$test);   

    }
    

}
